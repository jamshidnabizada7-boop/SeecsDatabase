package app;

public class HtmlTemplate {
    public static String render(String title, String bodyContent) {
        return String.format("""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>%s | SEECS Entrepreneurship Database</title>
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
            <style>
                :root {
                    --primary-color: #1e40af;
                    --primary-hover: #1d4ed8;
                    --secondary-color: #f8fafc;
                    --accent-color: #3b82f6;
                    --text-primary: #0f172a;
                    --text-secondary: #64748b;
                    --border-color: #e2e8f0;
                    --success-color: #10b981;
                    --warning-color: #f59e0b;
                    --error-color: #ef4444;
                    --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
                    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
                    --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
                    --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
                    --radius-sm: 0.375rem;
                    --radius-md: 0.5rem;
                    --radius-lg: 0.75rem;
                }
                
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                
                body {
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    line-height: 1.6;
                    color: var(--text-primary);
                    background: linear-gradient(135deg, #f1f5f9 0%%, #e2e8f0 100%%);
                    min-height: 100vh;
                }
                
                .header {
                    background: linear-gradient(135deg, var(--primary-color) 0%%, var(--accent-color) 100%%);
                    color: white;
                    padding: 2rem 0;
                    position: relative;
                    overflow: hidden;
                }
                
                .header::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: url("data:image/svg+xml,%%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%%3E%%3Cg fill='none' fill-rule='evenodd'%%3E%%3Cg fill='%%23ffffff' fill-opacity='0.05'%%3E%%3Ccircle cx='30' cy='30' r='4'/%%3E%%3C/g%%3E%%3C/g%%3E%%3C/svg%%3E");
                    animation: float 20s ease-in-out infinite;
                }
                
                @keyframes float {
                    0%%, 100%% { transform: translateY(0px); }
                    50%% { transform: translateY(-10px); }
                }
                
                .header-content {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 0 2rem;
                    position: relative;
                    z-index: 1;
                }
                
                .header h1 {
                    font-size: clamp(1.75rem, 4vw, 2.5rem);
                    font-weight: 700;
                    margin-bottom: 0.5rem;
                    letter-spacing: -0.025em;
                }
                
                .header-subtitle {
                    font-size: 1.125rem;
                    font-weight: 400;
                    opacity: 0.9;
                    color: #e2e8f0;
                }
                
                .main-container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 2rem;
                }
                
                .content-wrapper {
                    margin-top: -1rem;
                    position: relative;
                    z-index: 2;
                }
                
                .card {
                    background: white;
                    border-radius: var(--radius-lg);
                    padding: 1.5rem;
                    margin-bottom: 1.5rem;
                    box-shadow: var(--shadow-md);
                    border: 1px solid var(--border-color);
                    transition: all 0.2s ease;
                }
                
                .card:hover {
                    box-shadow: var(--shadow-lg);
                    transform: translateY(-2px);
                }
                
                .card-header {
                    margin-bottom: 1.5rem;
                    padding-bottom: 1rem;
                    border-bottom: 1px solid var(--border-color);
                }
                
                .card-title {
                    font-size: 1.5rem;
                    font-weight: 600;
                    color: var(--text-primary);
                    margin-bottom: 0.5rem;
                }
                
                .card-description {
                    color: var(--text-secondary);
                    font-size: 0.875rem;
                }
                
                .stats-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1rem;
                    margin-bottom: 2rem;
                }
                
                .stat-card {
                    background: white;
                    padding: 1.5rem;
                    border-radius: var(--radius-lg);
                    box-shadow: var(--shadow-sm);
                    border: 1px solid var(--border-color);
                    text-align: center;
                    transition: all 0.2s ease;
                }
                
                .stat-card:hover {
                    box-shadow: var(--shadow-md);
                }
                
                .stat-number {
                    font-size: 2rem;
                    font-weight: 700;
                    color: var(--primary-color);
                    margin-bottom: 0.5rem;
                }
                
                .stat-label {
                    color: var(--text-secondary);
                    font-size: 0.875rem;
                    font-weight: 500;
                }
                
                .table-container {
                    overflow-x: auto;
                    border-radius: var(--radius-lg);
                    box-shadow: var(--shadow-sm);
                    border: 1px solid var(--border-color);
                    background: white;
                }
                
                table {
                    width: 100%%;
                    border-collapse: collapse;
                    font-size: 0.875rem;
                }
                
                th {
                    background: var(--secondary-color);
                    color: var(--text-primary);
                    font-weight: 600;
                    padding: 1rem;
                    text-align: left;
                    border-bottom: 2px solid var(--border-color);
                    font-size: 0.75rem;
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                }
                
                td {
                    padding: 1rem;
                    border-bottom: 1px solid var(--border-color);
                    color: var(--text-primary);
                }
                
                tbody tr:hover {
                    background: #f8fafc;
                }
                
                tbody tr:last-child td {
                    border-bottom: none;
                }
                
                .btn {
                    display: inline-flex;
                    align-items: center;
                    gap: 0.5rem;
                    padding: 0.75rem 1.5rem;
                    font-size: 0.875rem;
                    font-weight: 500;
                    text-decoration: none;
                    border-radius: var(--radius-md);
                    transition: all 0.2s ease;
                    cursor: pointer;
                    border: none;
                    line-height: 1;
                }
                
                .btn-primary {
                    background: var(--primary-color);
                    color: white;
                }
                
                .btn-primary:hover {
                    background: var(--primary-hover);
                    transform: translateY(-1px);
                    box-shadow: var(--shadow-md);
                }
                
                .btn-secondary {
                    background: white;
                    color: var(--text-primary);
                    border: 1px solid var(--border-color);
                }
                
                .btn-secondary:hover {
                    background: var(--secondary-color);
                    border-color: var(--primary-color);
                }
                
                .btn-sm {
                    padding: 0.5rem 1rem;
                    font-size: 0.8125rem;
                }
                
                .badge {
                    display: inline-block;
                    padding: 0.25rem 0.75rem;
                    font-size: 0.75rem;
                    font-weight: 500;
                    border-radius: 9999px;
                    text-transform: uppercase;
                    letter-spacing: 0.025em;
                }
                
                .badge-success {
                    background: #dcfce7;
                    color: #166534;
                }
                
                .badge-warning {
                    background: #fef3c7;
                    color: #92400e;
                }
                
                .badge-error {
                    background: #fecaca;
                    color: #991b1b;
                }
                
                .badge-info {
                    background: #dbeafe;
                    color: #1e40af;
                }
                
                .grid {
                    display: grid;
                    gap: 1.5rem;
                }
                
                .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
                .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                .grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
                
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                
                .mb-4 { margin-bottom: 1rem; }
                .mb-6 { margin-bottom: 1.5rem; }
                .mt-4 { margin-top: 1rem; }
                .mt-6 { margin-top: 1.5rem; }
                
                .empty-state {
                    text-align: center;
                    padding: 3rem 1.5rem;
                    color: var(--text-secondary);
                }
                
                .empty-state-icon {
                    font-size: 3rem;
                    margin-bottom: 1rem;
                    opacity: 0.5;
                }
                
                .footer {
                    margin-top: 3rem;
                    padding: 2rem 0;
                    text-align: center;
                    color: var(--text-secondary);
                    font-size: 0.875rem;
                    border-top: 1px solid var(--border-color);
                    background: white;
                }
                
                @media (max-width: 768px) {
                    .main-container {
                        padding: 1rem;
                    }
                    
                    .card {
                        padding: 1rem;
                    }
                    
                    .header-content {
                        padding: 0 1rem;
                    }
                    
                    .grid-cols-2,
                    .grid-cols-3 {
                        grid-template-columns: repeat(1, minmax(0, 1fr));
                    }
                    
                    .stats-grid {
                        grid-template-columns: repeat(2, minmax(0, 1fr));
                    }
                    
                    table {
                        font-size: 0.8125rem;
                    }
                    
                    th, td {
                        padding: 0.75rem 0.5rem;
                    }
                }
                
                @media (max-width: 480px) {
                    .stats-grid {
                        grid-template-columns: repeat(1, minmax(0, 1fr));
                    }
                }
            </style>
        </head>
        <body>
            <header class="header">
                <div class="header-content">
                    <h1>%s</h1>
                    <p class="header-subtitle">SEECS Entrepreneurship Database</p>
                </div>
            </header>
            
            <div class="main-container">
                <div class="content-wrapper">
                    %s
                </div>
            </div>
            
            <footer class="footer">
                <p>&copy; 2025 SEECS Entrepreneurship Database. All rights reserved.</p>
            </footer>
        </body>
        </html>
        """, title, title, bodyContent);
    }
}