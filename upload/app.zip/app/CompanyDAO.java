package app;

import java.sql.*;
import java.util.*;

public class CompanyDAO {
    private final Connection conn;
    public CompanyDAO(Connection conn) { this.conn = conn; }

    /**
     * Flexible search: supported params (as keys in the `filters` map):
     *   degree, department, sector, startYear, endYear, country, city, status,
     *   minRevenue, maxRevenue
     *
     * NOTE: This method is written to work whether you store exact revenue (c.revenue)
     * or revenue ranges (c.revenue_min / c.revenue_max). For min/max filters we check both.
     */
    public List<Map<String,Object>> getCompaniesWithFilters(Map<String,String> filters) throws SQLException {
        String baseSql =
                "SELECT DISTINCT c.company_id, c.company_name, c.founded_year, " +
                        "c.revenue, c.revenue_min, c.revenue_max, s.name AS sector, " +
                        "f.degree, f.department, c.status, c.reason, l.city, l.country " +
                        "FROM company c " +
                        "LEFT JOIN sector s ON c.sector_id = s.sector_id " +
                        "LEFT JOIN founder f ON c.company_id = f.company_id " +
                        "LEFT JOIN location l ON c.location_id = l.location_id";

        List<String> conditions = new ArrayList<>();
        List<Object> params = new ArrayList<>();

        if (filters.containsKey("degree")) {
            conditions.add("f.degree = ?");
            params.add(filters.get("degree"));
        }
        if (filters.containsKey("department")) {
            conditions.add("f.department = ?");
            params.add(filters.get("department"));
        }
        if (filters.containsKey("sector")) {
            conditions.add("s.name = ?");
            params.add(filters.get("sector"));
        }
        if (filters.containsKey("startYear")) {
            conditions.add("c.founded_year >= ?");
            params.add(Integer.parseInt(filters.get("startYear")));
        }
        if (filters.containsKey("endYear")) {
            conditions.add("c.founded_year <= ?");
            params.add(Integer.parseInt(filters.get("endYear")));
        }
        if (filters.containsKey("country")) {
            conditions.add("l.country = ?");
            params.add(filters.get("country"));
        }
        if (filters.containsKey("city")) {
            conditions.add("l.city = ?");
            params.add(filters.get("city"));
        }
        if (filters.containsKey("status")) {
            conditions.add("c.status = ?");
            params.add(filters.get("status"));
        }
        if (filters.containsKey("minRevenue")) {
            conditions.add("((c.revenue IS NOT NULL AND c.revenue >= ?) OR (c.revenue_min IS NOT NULL AND c.revenue_min >= ?))");
            long v = Long.parseLong(filters.get("minRevenue"));
            params.add(v);
            params.add(v);
        }
        if (filters.containsKey("maxRevenue")) {
            conditions.add("((c.revenue IS NOT NULL AND c.revenue <= ?) OR (c.revenue_max IS NOT NULL AND c.revenue_max <= ?))");
            long v = Long.parseLong(filters.get("maxRevenue"));
            params.add(v);
            params.add(v);
        }

        StringBuilder sql = new StringBuilder(baseSql);
        if (!conditions.isEmpty()) {
            sql.append(" WHERE ");
            sql.append(String.join(" AND ", conditions));
        }
        sql.append(" ORDER BY c.founded_year DESC, c.company_name ASC");

        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                Object p = params.get(i);
                if (p instanceof Integer) ps.setInt(i+1, (Integer)p);
                else if (p instanceof Long) ps.setLong(i+1, (Long)p);
                else ps.setString(i+1, p.toString());
            }

            try (ResultSet rs = ps.executeQuery()) {
                List<Map<String,Object>> rows = new ArrayList<>();
                ResultSetMetaData md = rs.getMetaData();
                int cols = md.getColumnCount();
                while (rs.next()) {
                    Map<String,Object> row = new LinkedHashMap<>();
                    for (int c = 1; c <= cols; c++) {
                        row.put(md.getColumnLabel(c), rs.getObject(c));
                    }
                    rows.add(row);
                }
                return rows;
            }
        }
    }


    /**
     * Aggregation example: total (minimum estimate) revenue for companies matched by degree & year range.
     * Uses COALESCE(revenue, revenue_min, 0) so if a company only provides a revenue_min we count that
     * as its minimum contribution.
     */
    public long sumMinRevenueByDegreeAndYears(String degree, Integer startYear, Integer endYear) throws SQLException {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT SUM(COALESCE(c.revenue, c.revenue_min, 0)) AS total_min_rev ")
                .append("FROM company c JOIN founder f ON c.company_id = f.company_id ")
                .append("WHERE f.degree = ? ");
        List<Object> params = new ArrayList<>();
        params.add(degree);
        if (startYear != null) {
            sql.append(" AND c.founded_year >= ? ");
            params.add(startYear);
        }
        if (endYear != null) {
            sql.append(" AND c.founded_year <= ? ");
            params.add(endYear);
        }

        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i=0;i<params.size();i++) {
                Object p = params.get(i);
                if (p instanceof Integer) ps.setInt(i+1, (Integer)p);
                else ps.setString(i+1, p.toString());
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getLong("total_min_rev");
                return 0L;
            }
        }
    }

    /**
     * Count distinct founders (entrepreneurs) filtered by degree / year range
     */
    public int countEntrepreneursByDegreeAndYears(String degree, Integer startYear, Integer endYear) throws SQLException {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(DISTINCT f.founder_id) AS cnt ")
                .append("FROM founder f JOIN company c ON f.company_id = c.company_id ")
                .append("WHERE f.degree = ? ");
        List<Object> params = new ArrayList<>();
        params.add(degree);
        if (startYear != null) {
            sql.append(" AND c.founded_year >= ? ");
            params.add(startYear);
        }
        if (endYear != null) {
            sql.append(" AND c.founded_year <= ? ");
            params.add(endYear);
        }

        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i=0;i<params.size();i++) {
                Object p = params.get(i);
                if (p instanceof Integer) ps.setInt(i+1,(Integer)p);
                else ps.setString(i+1,p.toString());
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("cnt");
                return 0;
            }
        }
    }
}
