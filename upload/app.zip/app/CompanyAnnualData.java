package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CompanyAnnualData {
    public static void main(String[] args) throws Exception {
        int port = 8006;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addAnnualData", new AddHandler());
        server.createContext("/updateAnnualData", new UpdateHandler());
        server.createContext("/deleteAnnualData", new DeleteHandler());
        server.createContext("/viewAnnualData", new ViewHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Server started at http://localhost:" + port);
    }

    // ===== ROOT =====
    static class RootHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
                    <div class=\"card\">
                        <div class=\"card-header\">
                            <h1 class=\"card-title\">Company Annual Data</h1>
                            <p class=\"card-description\">Manage annual data: add or view company yearly records.</p>
                        </div>
                    
                        <div style=\"margin-top:20px;\">
                            <a href=\"/addAnnualData\" style=\"
                                padding:10px 20px;
                                background:#2196F3;
                                color:white;
                                text-decoration:none;
                                border-radius:6px;
                                margin-right:10px;
                                display:inline-block;
                            ">Add Annual Data</a>
                    
                            <a href=\"/viewAnnualData\" style=\"
                                padding:10px 20px;
                                background:#4CAF50;
                                color:white;
                                text-decoration:none;
                                border-radius:6px;
                                margin-right:10px;
                                display:inline-block;
                            ">View Annual Data</a>
                    
                            <a href=\"/\" style=\"
                                padding:10px 20px;
                                background:#9E9E9E;
                                color:white;
                                text-decoration:none;
                                border-radius:6px;
                                display:inline-block;
                            ">⬅ Back to Main Menu</a>
                        </div>
                    </div>
                    """;

            String html = HtmlTemplate.render("Company Annual Data", body);
            sendHtml(exchange, html);
        }
    }

    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    //AddHandler
    static class AddHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, "", "", "", "", "", ""); // default Add form
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else exchange.sendResponseHeaders(405, -1);
        }

        // Show form (Add)
        public void showForm(HttpExchange exchange, String companyId, String year, String revenueExact, String revenueMin, String revenueMax, String employeeCount) throws IOException {
            showForm(exchange, companyId, year, revenueExact, revenueMin, revenueMax, employeeCount, "/addAnnualData");
        }

        // Show form (Add or Update)
        public void showForm(HttpExchange exchange, String companyId, String year, String revenueExact, String revenueMin, String revenueMax, String employeeCount, String actionUrl) throws IOException {
            String body = """
                        <div class=\"card\" style=\"max-width:700px; margin:auto; padding:20px; border:1px solid #ccc; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,0.1);\">
                          <div class=\"card-header\" style=\"margin-bottom:15px;\">
                            <h2>%s Company Annual Data</h2>
                          </div>
                          <form method=\"post\" action=\"%s\">
                            <label>Company ID:</label><br>
                            <input type=\"number\" name=\"company_id\" value=\"%s\" required style=\"width:100%%; padding:8px; margin-bottom:12px;\"><br>
                    
                            <label>Year:</label><br>
                            <input type=\"number\" name=\"year\" value=\"%s\" required style=\"width:100%%; padding:8px; margin-bottom:12px;\"><br>
                    
                            <label>Revenue Exact:</label><br>
                            <input type=\"number\" step=\"0.01\" name=\"revenue_exact\" value=\"%s\" style=\"width:100%%; padding:8px; margin-bottom:12px;\"><br>
                    
                            <label>Revenue Min:</label><br>
                            <input type=\"number\" step=\"0.01\" name=\"revenue_min\" value=\"%s\" style=\"width:100%%; padding:8px; margin-bottom:12px;\"><br>
                    
                            <label>Revenue Max:</label><br>
                            <input type=\"number\" step=\"0.01\" name=\"revenue_max\" value=\"%s\" style=\"width:100%%; padding:8px; margin-bottom:12px;\"><br>
                    
                            <label>Employee Count:</label><br>
                            <input type=\"number\" name=\"employee_count\" value=\"%s\" style=\"width:100%%; padding:8px; margin-bottom:12px;\"><br>
                    
                            <button type=\"submit\" style=\"padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;\">Save</button>
                          </form>
                          <div style=\"margin-top:15px;\">
                            <a href=\"/viewAnnualData\" style=\"padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px;\">View Annual Data</a>
                            <a href=\"/\" style=\"padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; margin-left:8px;\">⬅ Back</a>
                          </div>
                        </div>
                    """.formatted(actionUrl.equals("/addAnnualData") ? "Add" : "Update", actionUrl, companyId, year, revenueExact, revenueMin, revenueMax, employeeCount);

            sendHtml(exchange, HtmlTemplate.render(actionUrl.equals("/addAnnualData") ? "Add Company Annual Data" : "Update Company Annual Data", body));
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String companyId = params.get("company_id");
            String year = params.get("year");
            String revenueExact = params.get("revenue_exact");
            String revenueMin = params.get("revenue_min");
            String revenueMax = params.get("revenue_max");
            String employeeCount = params.get("employee_count");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO company_annual_data (company_id, year, revenue_exact, revenue_min, revenue_max, employee_count) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(companyId));
                ps.setInt(2, Integer.parseInt(year));
                if (revenueExact.isEmpty()) ps.setNull(3, Types.DECIMAL);
                else ps.setBigDecimal(3, new java.math.BigDecimal(revenueExact));
                if (revenueMin.isEmpty()) ps.setNull(4, Types.DECIMAL);
                else ps.setBigDecimal(4, new java.math.BigDecimal(revenueMin));
                if (revenueMax.isEmpty()) ps.setNull(5, Types.DECIMAL);
                else ps.setBigDecimal(5, new java.math.BigDecimal(revenueMax));
                if (employeeCount.isEmpty()) ps.setNull(6, Types.INTEGER);
                else ps.setInt(6, Integer.parseInt(employeeCount));
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewAnnualData");
            exchange.sendResponseHeaders(302, -1);
        }

        public Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            Map<String, String> map = new HashMap<>();
            for (String pair : body.toString().split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }

        private void sendHtml(HttpExchange exchange, String html) throws IOException {
            byte[] resp = html.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(resp);
            }
        }
    }


    // ===== VIEW =====
    static class ViewHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card' style='max-width:95%; margin:auto; padding:20px; border:1px solid #ccc; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,0.1);'>")
                    .append("<div class='card-header' style='margin-bottom:15px;'>")
                    .append("<h2>Company Annual Data List</h2>")
                    .append("<p>Below is the list of annual company records</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>Company ID</th><th>Year</th><th>Revenue Exact</th><th>Revenue Min</th><th>Revenue Max</th><th>Employees</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT * FROM company_annual_data ORDER BY id";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    int id = rs.getInt("id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(rs.getInt("company_id")).append("</td>")
                            .append("<td>").append(rs.getInt("year")).append("</td>")
                            .append("<td>").append(rs.getBigDecimal("revenue_exact") != null ? rs.getBigDecimal("revenue_exact") : "").append("</td>")
                            .append("<td>").append(rs.getBigDecimal("revenue_min") != null ? rs.getBigDecimal("revenue_min") : "").append("</td>")
                            .append("<td>").append(rs.getBigDecimal("revenue_max") != null ? rs.getBigDecimal("revenue_max") : "").append("</td>")
                            .append("<td>").append(rs.getInt("employee_count")).append("</td>")
                            .append("<td>")
                            .append("<a href='/updateAnnualData?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteAnnualData?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' style='padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Company Annual Data List", body.toString());
            sendHtml(exchange, html);
        }

        private void sendHtml(HttpExchange exchange, String html) throws IOException {
            byte[] resp = html.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(resp);
            }
        }
    }

    // ===== UPDATE =====
    static class UpdateHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> queryParams = parseQuery(exchange);
            String idStr = queryParams.get("id");
            if (idStr == null) {
                exchange.sendResponseHeaders(400, -1);
                return;
            }
            int id = Integer.parseInt(idStr);

            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                // Show pre-filled form
                showForm(exchange, id);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                // Handle update submission
                handleUpdate(exchange, id);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, int id) throws IOException {
            String companyId = "", year = "", revenueExact = "", revenueMin = "", revenueMax = "", employeeCount = "";

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT * FROM company_annual_data WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    // company_id
                    Object compObj = rs.getObject("company_id");
                    companyId = compObj != null ? compObj.toString() : "";

                    // year (YEAR may be null)
                    Object yearObj = rs.getObject("year");
                    year = yearObj != null ? yearObj.toString() : "";

                    // revenue_exact / min / max
                    revenueExact = rs.getBigDecimal("revenue_exact") != null ? rs.getBigDecimal("revenue_exact").toString() : "";
                    revenueMin = rs.getBigDecimal("revenue_min") != null ? rs.getBigDecimal("revenue_min").toString() : "";
                    revenueMax = rs.getBigDecimal("revenue_max") != null ? rs.getBigDecimal("revenue_max").toString() : "";

                    // employee_count
                    Object empObj = rs.getObject("employee_count");
                    employeeCount = empObj != null ? empObj.toString() : "";
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Use AddHandler.form with custom POST URL for update (7 args)
            new AddHandler().showForm(exchange, companyId, year, revenueExact, revenueMin, revenueMax, employeeCount,
                    "/updateAnnualData?id=" + id);
        }

        private void handleUpdate(HttpExchange exchange, int id) throws IOException {
            Map<String, String> params = new AddHandler().parseFormData(exchange);
            String companyId = params.get("company_id");
            String year = params.get("year");
            String revenueExact = params.get("revenue_exact");
            String revenueMin = params.get("revenue_min");
            String revenueMax = params.get("revenue_max");
            String employeeCount = params.get("employee_count");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE company_annual_data SET company_id=?, year=?, revenue_exact=?, revenue_min=?, revenue_max=?, employee_count=? WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);

                // company_id (required)
                ps.setInt(1, Integer.parseInt(companyId));

                // year (may be blank)
                if (year == null || year.isEmpty()) ps.setNull(2, Types.INTEGER);
                else ps.setInt(2, Integer.parseInt(year));

                // revenue_exact
                if (revenueExact == null || revenueExact.isEmpty()) ps.setNull(3, Types.DECIMAL);
                else ps.setBigDecimal(3, new java.math.BigDecimal(revenueExact));

                // revenue_min
                if (revenueMin == null || revenueMin.isEmpty()) ps.setNull(4, Types.DECIMAL);
                else ps.setBigDecimal(4, new java.math.BigDecimal(revenueMin));

                // revenue_max
                if (revenueMax == null || revenueMax.isEmpty()) ps.setNull(5, Types.DECIMAL);
                else ps.setBigDecimal(5, new java.math.BigDecimal(revenueMax));

                // employee_count
                if (employeeCount == null || employeeCount.isEmpty()) ps.setNull(6, Types.INTEGER);
                else ps.setInt(6, Integer.parseInt(employeeCount));

                // where id = ?
                ps.setInt(7, id);
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Redirect back to the list page
            exchange.getResponseHeaders().set("Location", "/viewAnnualData");
            exchange.sendResponseHeaders(302, -1);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== DELETE =====
    static class DeleteHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";

            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM company_annual_data WHERE id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "✅ Deleted successfully!" : "❌ Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "❌ Error: " + e.getMessage();
                }
            }

            String body = String.format("""
                    <div class="card">
                      <div class="card-header">
                        <h2>Delete Company Annual Data</h2>
                      </div>
                      <div class="card-body" style="text-align:center;">
                        <p>%s</p>
                        <a href="/viewAnnualData"
                           style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
                           ⬅ Back to List
                        </a>
                      </div>
                    </div>
                    """, escapeHtml(message));

            String html = HtmlTemplate.render("Delete Company Annual Data", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }

        private void sendHtml(HttpExchange exchange, String html) throws IOException {
            byte[] resp = html.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(resp);
            }
        }
    }
}