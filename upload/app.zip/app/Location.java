package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Location {
    public static void main(String[] args) throws Exception {
        int port = 8002; // Use a new port
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addLocation", new AddLocationHandler());
        server.createContext("/updateLocation", new UpdateLocationHandler());
        server.createContext("/deleteLocation", new DeleteLocationHandler());
        server.createContext("/viewLocations", new ViewLocationHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Location server started at http://localhost:" + port);
    }

    // ===== ROOT PAGE =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h1 class="card-title">Location Management</h1>
                        <p class="card-description">Manage locations: add or view.</p>
                      </div>
                      <div style='margin-top:20px;'>
                        <a href="/addLocation" 
                           style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">
                           ➕ Add Location
                        </a>
                        <a href="/viewLocations" 
                           style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block;">
                           📋 View Locations
                        </a>
                        <a href="/" 
                           style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-left:10px;">
                           ⬅ Back to Main Menu
                        </a>
                      </div>
                    </div>
                    """;

            String html = HtmlTemplate.render("Location Management", body);
            sendHtml(exchange, html);
        }
    }

    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ===== ADD LOCATION =====
    static class AddLocationHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, "", "", "");
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String city, String country, String message) throws IOException {
            String msgHtml = "";
            if (message != null && !message.isEmpty()) {
                msgHtml = "<div style='margin-bottom:15px; padding:10px; background:#e8f5e9; border:1px solid #4CAF50; border-radius:6px; color:#2e7d32;'>"
                        + escapeHtml(message) + "</div>";
            }

            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h2 class="card-title">Add Location</h2>
                        <p class="card-description">Fill out the form below to add a new location.</p>
                      </div>
                      <div class="card-body">
                        %s
                        <form method="post" action="/addLocation" style="max-width:400px;">
                          <label>City:</label><br>
                          <input type="text" name="city" value="%s" style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                    
                          <label>Country:</label><br>
                          <input type="text" name="country" value="%s" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                    
                          <button type="submit" 
                                  style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
                                  ➕ Add Location
                          </button>
                        </form>
                        <br>
                        <a href="/viewLocations" style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:8px;">
                          📋 View Locations
                        </a>
                        <a href="/" style="padding:8px 16px; background:#9e9e9e; color:white; text-decoration:none; border-radius:6px;">
                          ⬅ Back
                        </a>
                      </div>
                    </div>
                    """.formatted(msgHtml, escapeHtml(city), escapeHtml(country));

            String html = HtmlTemplate.render("Add Location", body);
            sendHtml(exchange, html);
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String city = params.getOrDefault("city", "");
            String country = params.getOrDefault("country", "");

            String message;
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO location (city, country) VALUES (?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                if (city.isEmpty()) ps.setNull(1, Types.VARCHAR);
                else ps.setString(1, city);
                ps.setString(2, country);
                int rows = ps.executeUpdate();
                message = rows > 0 ? "✅ Location added successfully!" : "❌ Insert failed.";
            } catch (Exception e) {
                e.printStackTrace();
                message = "❌ Error: " + e.getMessage();
            }

            showForm(exchange, "", "", message);
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            String formData = body.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }
    // ===== VIEW LOCATIONS =====
    static class ViewLocationHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Location List</h2>")
                    .append("<p class='card-description'>Below is the list of saved locations</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:400px; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>City</th><th>Country</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM location ORDER BY location_id");
                while (rs.next()) {
                    int id = rs.getInt("location_id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("city"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("country"))).append("</td>")
                            .append("<td>")
                            .append("<a href='/updateLocation?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteLocation?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' style='padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Location List", body.toString());
            sendHtml(exchange, html);
        }
    }

    // ===== UPDATE LOCATION =====
    static class UpdateLocationHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                Map<String, String> params = parseQuery(exchange);
                String idStr = params.get("id");
                if (idStr != null) {
                    try (Connection conn = DBUtil.getConnection()) {
                        String sql = "SELECT * FROM location WHERE location_id=?";
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setInt(1, Integer.parseInt(idStr));
                        ResultSet rs = ps.executeQuery();
                        if (rs.next()) {
                            showForm(exchange, rs.getString("city"), rs.getString("country"), rs.getInt("location_id"));
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                exchange.sendResponseHeaders(404, -1);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, String city, String country, int locationId) throws IOException {
            String body = String.format("""
                    <div class="card">
                      <div class="card-header"><h2>Update Location</h2></div>
                      <div class="card-body" style="text-align:center;">
                        <form method="post" action="/updateLocation">
                          <input type="hidden" name="id" value="%d">
                          <div class="form-group">
                            <label>City:</label>
                            <input type="text" name="city" value="%s" style="padding:8px; width:100%%;">
                          </div>
                          <div class="form-group">
                            <label>Country:</label>
                            <input type="text" name="country" value="%s" required style="padding:8px; width:100%%;">
                          </div>
                          <button type="submit" style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
                            Update Location
                          </button>
                        </form>
                        <div style="margin-top:15px;">
                          <a href="/viewLocations" style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px;">⬅ Back</a>
                        </div>
                      </div>
                    </div>
                    """, locationId, escapeHtml(city), escapeHtml(country));

            String html = HtmlTemplate.render("Update Location", body);
            sendHtml(exchange, html);
        }

        private void handleUpdate(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String idStr = params.get("id");
            String city = params.get("city");
            String country = params.get("country");
            if (idStr == null) return;

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE location SET city=?, country=? WHERE location_id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                if (city.isEmpty()) ps.setNull(1, Types.VARCHAR);
                else ps.setString(1, city);
                ps.setString(2, country);
                ps.setInt(3, Integer.parseInt(idStr));
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewLocations");
            exchange.sendResponseHeaders(302, -1);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            String formData = body.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== DELETE LOCATION =====
    static class DeleteLocationHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";
            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM location WHERE location_id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "Location deleted successfully!" : "Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "Error: " + e.getMessage();
                }
            }

            String body = String.format("""
                    <div class="card">
                      <div class="card-header"><h2>Delete Location</h2></div>
                      <div class="card-body" style="text-align:center;">
                        <p>%s</p>
                        <a href="/viewLocations" style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px;">⬅ Back to Location List</a>
                      </div>
                    </div>
                    """, escapeHtml(message));

            String html = HtmlTemplate.render("Delete Location", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }
}