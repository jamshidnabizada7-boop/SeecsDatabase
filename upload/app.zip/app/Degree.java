package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Degree {
    public static void main(String[] args) throws Exception {
        int port = 8003; // New port for Degree
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addDegree", new AddDegreeHandler());
        server.createContext("/updateDegree", new UpdateDegreeHandler());
        server.createContext("/deleteDegree", new DeleteDegreeHandler());
        server.createContext("/viewDegrees", new ViewDegreeHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Degree server started at http://localhost:" + port);
    }

    // ===== ROOT PAGE =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h1 class="card-title">Degree Management</h1>
                        <p class="card-description">Manage degrees: add or view existing degrees.</p>
                      </div>
                      <div style='margin-top:20px;'>
                        <a href="/addDegree" style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">Add Degree</a>
                        <a href="/viewDegrees" style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block;">View Degrees</a>
                        <a href="/" style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-left:10px;">⬅ Back to Main Menu</a>
                      </div>
                    </div>
                    """;

            String html = HtmlTemplate.render("Degree Management", body);
            sendHtml(exchange, html);
        }
    }

    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ===== ADD DEGREE =====
    static class AddDegreeHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, "", "", "");
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, String name, String department, String year) throws IOException {
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h2 class="card-title">Add Degree</h2>
                        <p class="card-description">Fill out the form below to add a new degree.</p>
                      </div>
                      <div class="card-body">
                        <form method="post" action="/addDegree" style="max-width:500px;">
                          <label>Name:</label><br>
                          <input type="text" name="name" value="%s" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                    
                          <label>Department:</label><br>
                          <input type="text" name="department" value="%s" style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                    
                          <label>Graduation Year:</label><br>
                          <input type="number" name="graduation_year" value="%s" min="1900" max="2100" style="padding:8px; margin-bottom:12px;"><br>
                    
                          <button type="submit" style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
                            ➕ Add Degree
                          </button>
                        </form>
                        <div style="margin-top:15px;">
                          <a href="/viewDegrees" style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:8px;">📋 View Degrees</a>
                          <a href="/" style="padding:8px 16px; background:#9e9e9e; color:white; text-decoration:none; border-radius:6px;">⬅ Back</a>
                        </div>
                      </div>
                    </div>
                    """.formatted(escapeHtml(name), escapeHtml(department), escapeHtml(year));

            String html = HtmlTemplate.render("Add Degree", body);
            sendHtml(exchange, html);
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);

            String name = params.getOrDefault("name", "");
            String department = params.getOrDefault("department", "");
            String yearStr = params.getOrDefault("graduation_year", "");

            Integer year = null;
            if (!yearStr.isEmpty()) {
                try {
                    year = Integer.parseInt(yearStr);
                } catch (NumberFormatException ignored) {
                }
            }

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO degree (name, department, graduation_year) VALUES (?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                if (department.isEmpty()) ps.setNull(2, Types.VARCHAR);
                else ps.setString(2, department);
                if (year != null) ps.setInt(3, year);
                else ps.setNull(3, Types.INTEGER);
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            showForm(exchange, "", "", "");
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);

            Map<String, String> map = new HashMap<>();
            if (body.length() == 0) return map;
            for (String pair : body.toString().split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }


    // ===== VIEW DEGREES =====
    static class ViewDegreeHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Degree List</h2>")
                    .append("<p class='card-description'>Below is the list of registered degrees</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>Name</th><th>Department</th><th>Graduation Year</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM degree ORDER BY degree_id");
                while (rs.next()) {
                    int id = rs.getInt("degree_id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("name"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("department"))).append("</td>")
                            .append("<td>").append(rs.getInt("graduation_year") != 0 ? rs.getInt("graduation_year") : "").append("</td>")
                            .append("<td>")
                            .append("<a href='/updateDegree?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteDegree?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' class='btn btn-secondary'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Degree List", body.toString());
            sendHtml(exchange, html);
        }
    }


    // ===== UPDATE DEGREE =====
    static class UpdateDegreeHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                Map<String, String> params = parseQuery(exchange);
                String idStr = params.get("id");
                if (idStr != null) {
                    try (Connection conn = DBUtil.getConnection()) {
                        String sql = "SELECT * FROM degree WHERE degree_id=?";
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setInt(1, Integer.parseInt(idStr));
                        ResultSet rs = ps.executeQuery();
                        if (rs.next()) {
                            showForm(exchange,
                                    rs.getString("name"),
                                    rs.getString("department"),
                                    rs.getString("graduation_year"),
                                    rs.getInt("degree_id"));
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                exchange.sendResponseHeaders(404, -1);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String name, String department, String year, int degreeId) throws IOException {
            String html = """
                    <html>
                    <head>
                      <style>
                        body { font-family: Arial, sans-serif; background:#f9f9f9; margin:20px; }
                        .card { background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.1); max-width:500px; margin:auto; }
                        h2 { margin-top:0; }
                        .form-group { margin-bottom:15px; }
                        label { display:block; font-weight:bold; margin-bottom:5px; }
                        input[type=text], input[type=number] { width:100%; padding:8px; border:1px solid #ccc; border-radius:4px; }
                        .actions { margin-top:20px; }
                        .btn { padding:10px 16px; border:none; border-radius:4px; cursor:pointer; text-decoration:none; display:inline-block; }
                        .btn-primary { background:#4CAF50; color:white; }
                        .btn-secondary { background:#9E9E9E; color:white; margin-left:10px; }
                      </style>
                    </head>
                    <body>
                      <div class="card">
                        <h2>Update Degree</h2>
                        <form method='post' action='/updateDegree'>
                    """;

            html += "<input type='hidden' name='id' value='" + degreeId + "'>";

            html += "<div class='form-group'><label>Name</label>"
                    + "<input type='text' name='name' value='" + escapeHtml(name) + "' required></div>";

            html += "<div class='form-group'><label>Department</label>"
                    + "<input type='text' name='department' value='" + escapeHtml(department) + "'></div>";

            html += "<div class='form-group'><label>Graduation Year</label>"
                    + "<input type='number' name='graduation_year' min='1900' max='2100' value='" + year + "'></div>";

            html += "<div class='actions'>"
                    + "<input type='submit' value='Update Degree' class='btn btn-primary'>"
                    + "<a href='/viewDegrees' class='btn btn-secondary'>Back</a>"
                    + "</div>";

            html += "</form></div></body></html>";

            byte[] resp = html.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(resp);
            }
        }

        private void handleUpdate(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String idStr = params.get("id");
            String name = params.get("name");
            String department = params.get("department");
            String yearStr = params.get("graduation_year");

            Integer year = null;
            if (!yearStr.isEmpty()) {
                try {
                    year = Integer.parseInt(yearStr);
                } catch (NumberFormatException ignored) {
                }
            }

            if (idStr == null) return;
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE degree SET name=?, department=?, graduation_year=? WHERE degree_id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                if (department.isEmpty()) ps.setNull(2, Types.VARCHAR);
                else ps.setString(2, department);
                if (year != null) ps.setInt(3, year);
                else ps.setNull(3, Types.INTEGER);
                ps.setInt(4, Integer.parseInt(idStr));
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewDegrees");
            exchange.sendResponseHeaders(302, -1);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            String formData = body.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }


    // ===== DELETE DEGREE =====
    static class DeleteDegreeHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";

            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM degree WHERE degree_id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "Degree deleted successfully!" : "Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "Error: " + e.getMessage();
                }
            }

            String body = String.format("""
                    <div class="card">
                      <div class="card-header">
                        <h2>Delete Degree</h2>
                      </div>
                      <div class="card-body" style="text-align:center;">
                        <p>%s</p>
                        <a href="/viewDegrees"
                           style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
                           ⬅ Back to Degree List
                        </a>
                      </div>
                    </div>
                    """, escapeHtml(message));

            String html = HtmlTemplate.render("Delete Degree", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }
}