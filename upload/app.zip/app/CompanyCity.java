package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CompanyCity {
    public static void main(String[] args) throws Exception {
        int port = 8010;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addCompanyCity", new AddHandler());
        server.createContext("/updateCompanyCity", new UpdateHandler());
        server.createContext("/deleteCompanyCity", new DeleteHandler());
        server.createContext("/viewCompanyCity", new ViewHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Server started at http://localhost:" + port);
    }

    // ===== ROOT =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
<div class="card">
  <div class="card-header">
    <h1 class="card-title">Company Branches</h1>
    <p class="card-description">Manage company branches: add or view existing branches.</p>
  </div>
  <div style='margin-top:20px;'>
    <a href="/addCompanyCity" 
       style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">
       ➕ Add Branch
    </a>
    <a href="/viewCompanyCity" 
       style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block;">
       📋 View Branches
    </a>
    <a href="/" 
       style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; display:inline-block;">
       ⬅ Back to Main Menu
    </a>
  </div>
</div>
""";

            String html = HtmlTemplate.render("Company Branches", body);
            sendHtml(exchange, html);
        }
    }
    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ===== ADD =====
    static class AddHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, "", "");
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String companyId, String locationId) throws IOException {
            String body = """
<div class="card">
  <div class="card-header">
    <h2 class="card-title">Add Company Branch</h2>
    <p class="card-description">Fill out the form below to add a new branch.</p>
  </div>
  <div class="card-body">
    <form method="post" action="/addCompanyCity" style="max-width:400px;">
      <label>Company ID:</label><br>
      <input type="number" name="company_id" value="%s" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>

      <label>Location ID:</label><br>
      <input type="number" name="location_id" value="%s" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>

      <button type="submit" 
              style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
              ➕ Save Branch
      </button>
    </form>
    <br>
    <a href="/viewCompanyCity" 
       style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px;">
       📋 View Branches
    </a>
    <a href="/" 
       style="padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;">
       ⬅ Back
    </a>
  </div>
</div>
""".formatted(companyId, locationId);

            String html = HtmlTemplate.render("Add Company Branch", body);
            sendHtml(exchange, html);
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String companyId = params.get("company_id");
            String locationId = params.get("location_id");
            String message;

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO company_city (company_id, location_id) VALUES (?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(companyId));
                ps.setInt(2, Integer.parseInt(locationId));
                int rows = ps.executeUpdate();
                message = rows > 0 ? "✅ Branch added successfully!" : "❌ Add failed!";
            } catch (Exception e) {
                e.printStackTrace();
                message = "❌ Error: " + e.getMessage();
            }

            String body = """
<div class="card">
  <div class="card-header">
    <h2>Add Company Branch</h2>
  </div>
  <div class="card-body" style="text-align:center;">
    <p>%s</p>
    <a href="/viewCompanyCity" 
       style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px;">
       ⬅ Back to list
    </a>
  </div>
</div>
""".formatted(escapeHtml(message));

            String html = HtmlTemplate.render("Add Company Branch", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            Map<String, String> map = new HashMap<>();
            for (String pair : body.toString().split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== VIEW =====
    static class ViewHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Company Branch List</h2>")
                    .append("<p class='card-description'>Below is the list of company branches (city-wise)</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>Company ID</th><th>Location ID</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT * FROM company_city";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    int id = rs.getInt("id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(rs.getInt("company_id")).append("</td>")
                            .append("<td>").append(rs.getInt("location_id")).append("</td>")
                            .append("<td>")
                            .append("<a href='/updateCompanyCity?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteCompanyCity?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' style='padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Company Branch List", body.toString());
            sendHtml(exchange, html);
        }
    }


    // ===== DELETE COMPANY BRANCH =====
    static class DeleteHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";
            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM company_city WHERE id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "Deleted successfully!" : "Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "Error: " + e.getMessage();
                }
            }

            String body = String.format("""
<div class="card">
  <div class="card-header">
    <h2>Delete Company Branch</h2>
  </div>
  <div class="card-body" style="text-align:center;">
    <p>%s</p>
    <a href="/viewCompanyCity"
       style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
       ⬅ Back to Branch List
    </a>
  </div>
</div>
""", escapeHtml(message));

            String html = HtmlTemplate.render("Delete Company Branch", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== UPDATE =====
    static class UpdateHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            if (idStr == null) {
                exchange.sendResponseHeaders(400, -1);
                return;
            }
            int id = Integer.parseInt(idStr);
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, id);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange, id);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, int id) throws IOException {
            String companyId = "", locationId = "";
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT * FROM company_city WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    companyId = String.valueOf(rs.getInt("company_id"));
                    locationId = String.valueOf(rs.getInt("location_id"));
                }
            } catch (Exception e) { e.printStackTrace(); }
            new AddHandler().showForm(exchange, companyId, locationId);
        }

        private void handleUpdate(HttpExchange exchange, int id) throws IOException {
            Map<String, String> params = new AddHandler().parseFormData(exchange);
            String companyId = params.get("company_id");
            String locationId = params.get("location_id");
            String message;

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE company_city SET company_id=?, location_id=? WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(companyId));
                ps.setInt(2, Integer.parseInt(locationId));
                ps.setInt(3, id);
                int rows = ps.executeUpdate();
                message = rows > 0 ? "Updated successfully!" : "Update failed!";
            } catch (Exception e) { e.printStackTrace(); message = "Error: " + e.getMessage(); }

            String response = "<html><body><h3>" + message + "</h3><a href='/viewCompanyCity'>Back to list</a></body></html>";
            byte[] resp = response.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) { os.write(resp); }
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }
}
