package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Founder {
    public static void main(String[] args) throws Exception {
        int port = 8000; // you can change this if 8000 is used
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        // Contexts
        server.createContext("/", new RootHandler());
        server.createContext("/addFounder", new AddFounderHandler());
        server.createContext("/deleteFounder", new DeleteFounderHandler());
        server.createContext("/updateFounder", new UpdateFounderHandler());
        server.createContext("/viewFounders", new ViewFounderHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Server started at http://localhost:" + port);
    }

    // ===== ROOT =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h1 class="card-title">Founder Management</h1>
                        <p class="card-description">Manage founders: add or view.</p>
                      </div>
                      <div style='margin-top:20px;'>
                        <a href="/addFounder" style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">Add Founder</a>
                        <a href="/viewFounders" style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block;">View Founders</a>
                        <a href="/" style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; display:inline-block;">⬅ Back to Main Menu</a>
                      </div>
                    </div>
                    """;

            String html = HtmlTemplate.render("Founder Management", body);
            sendHtml(exchange, html);
        }
    }

    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ===== ADD FOUNDER =====
    static class AddFounderHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, null, null, null);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String name, String gender, String degreeId) throws IOException {
            String msgHtml = "";
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h2 class="card-title">Add Founder</h2>
                        <p class="card-description">Fill out the form below to add a new founder.</p>
                      </div>
                      <div class="card-body">
                        %s
                        <form method="post" action="/addFounder" style="max-width:600px;">
                          <label>Name:</label><br>
                          <input type="text" name="name" value="%s" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                    
                          <label>Gender:</label><br>
                          <select name="gender" style="width:100%%; padding:8px; margin-bottom:12px;">
                            <option%s>Male</option>
                            <option%s>Female</option>
                            <option%s>Other</option>
                          </select><br>
                    
                          <label>Degree ID:</label><br>
                          <input type="number" name="degree_id" value="%s" style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                    
                          <button type="submit" style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
                            ➕ Add Founder
                          </button>
                        </form>
                        <br>
                        <div style="margin-top:15px;">
                          <a href="/viewFounders"
                             style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:8px;">
                             📋 View Founders
                          </a>
                          <a href="/" style="padding:8px 16px; background:#9e9e9e; color:white; text-decoration:none; border-radius:6px;">
                             ⬅ Back
                          </a>
                        </div>
                      </div>
                    </div>
                    """.formatted(
                    msgHtml,
                    escapeHtml(name == null ? "" : name),
                    "Male".equals(gender) ? " selected" : "",
                    "Female".equals(gender) ? " selected" : "",
                    "Other".equals(gender) ? " selected" : "",
                    escapeHtml(degreeId == null ? "" : degreeId)
            );

            String html = HtmlTemplate.render("Add Founder", body);
            sendHtml(exchange, html);
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String name = params.getOrDefault("name", "");
            String gender = params.getOrDefault("gender", "");
            String degreeIdStr = params.getOrDefault("degree_id", "");
            Integer degreeId = null;
            try {
                if (!degreeIdStr.isEmpty()) degreeId = Integer.parseInt(degreeIdStr);
            } catch (NumberFormatException ignored) {
            }

            String message;
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO founder (name, gender, degree_id) VALUES (?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, gender);
                if (degreeId != null) ps.setInt(3, degreeId);
                else ps.setNull(3, Types.INTEGER);
                int rows = ps.executeUpdate();
                message = rows > 0 ? "✅ Founder added successfully!" : "❌ Insert failed.";
            } catch (Exception e) {
                e.printStackTrace();
                message = "❌ Error: " + e.getMessage();
            }

            showForm(exchange, "", "", "");
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            String formData = body.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== DELETE FOUNDER =====
    static class DeleteFounderHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";

            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM founder WHERE founder_id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "Founder deleted successfully!" : "Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "Error: " + e.getMessage();
                }
            }

            String body = String.format("""
            <div class="card">
              <div class="card-header">
                <h2>Delete Founder</h2>
              </div>
              <div class="card-body" style="text-align:center;">
                <p>%s</p>
                <a href="/viewFounders"
                   style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
                   ⬅ Back to Founder List
                </a>
              </div>
            </div>
            """, escapeHtml(message));

            String html = HtmlTemplate.render("Delete Founder", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }


    // ===== UPDATE FOUNDER =====
    static class UpdateFounderHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                Map<String, String> params = parseQuery(exchange);
                String idStr = params.get("id");
                if (idStr != null) {
                    try (Connection conn = DBUtil.getConnection()) {
                        String sql = "SELECT * FROM founder WHERE founder_id=?";
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setInt(1, Integer.parseInt(idStr));
                        ResultSet rs = ps.executeQuery();
                        if (rs.next()) {
                            showForm(exchange,
                                    rs.getString("name"),
                                    rs.getString("gender"),
                                    rs.getString("degree_id"),
                                    rs.getInt("founder_id"));
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                exchange.sendResponseHeaders(404, -1);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, String name, String gender, String degreeId, int founderId) throws IOException {
            String body = String.format("""
            <div class="card">
              <div class="card-header">
                <h2>Update Founder</h2>
              </div>
              <div class="card-body">
                <form method='post' action='/updateFounder'>
                  <input type='hidden' name='id' value='%d'>
                  <div class='form-group'>
                    <label>Name</label>
                    <input type='text' name='name' value='%s' required>
                  </div>
                  <div class='form-group'>
                    <label>Gender</label>
                    <select name='gender'>
                      <option%s>Male</option>
                      <option%s>Female</option>
                      <option%s>Other</option>
                    </select>
                  </div>
                  <div class='form-group'>
                    <label>Degree ID</label>
                    <input type='number' name='degree_id' value='%s'>
                  </div>
                  <div class='actions'>
                    <input type='submit' value='Update Founder' class='btn btn-primary'>
                    <a href='/viewFounders' class='btn btn-secondary'>Back</a>
                  </div>
                </form>
              </div>
            </div>
            """,
                    founderId,
                    escapeHtml(name),
                    "Male".equals(gender) ? " selected" : "",
                    "Female".equals(gender) ? " selected" : "",
                    "Other".equals(gender) ? " selected" : "",
                    escapeHtml(degreeId)
            );

            String html = HtmlTemplate.render("Update Founder", body);
            sendHtml(exchange, html);
        }

        private void handleUpdate(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String idStr = params.get("id");
            if (idStr == null) return;

            String name = params.getOrDefault("name", "");
            String gender = params.getOrDefault("gender", "");
            String degreeIdStr = params.getOrDefault("degree_id", "");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE founder SET name=?, gender=?, degree_id=? WHERE founder_id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, gender);
                if (!degreeIdStr.isEmpty()) ps.setInt(3, Integer.parseInt(degreeIdStr));
                else ps.setNull(3, Types.INTEGER);
                ps.setInt(4, Integer.parseInt(idStr));
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewFounders");
            exchange.sendResponseHeaders(302, -1);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            String formData = body.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            for (String pair : formData.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== VIEW FOUNDERS =====
    static class ViewFounderHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Founder List</h2>")
                    .append("<p class='card-description'>Below is the list of registered founders</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>Name</th><th>Gender</th><th>Degree ID</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM founder ORDER BY founder_id");
                while (rs.next()) {
                    int id = rs.getInt("founder_id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("name"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("gender"))).append("</td>")
                            .append("<td>").append(rs.getInt("degree_id") != 0 ? rs.getInt("degree_id") : "").append("</td>")
                            .append("<td>")
                            .append("<a href='/updateFounder?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteFounder?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' class='btn btn-secondary'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Founder List", body.toString());
            sendHtml(exchange, html);
        }
    }
}
