package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Company {
    public static void main(String[] args) throws Exception {
        int port = 8004; // port for Company
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addCompany", new AddCompanyHandler());
        server.createContext("/viewCompanies", new ViewCompanyHandler());
        server.createContext("/updateCompany", new UpdateCompanyHandler());
        server.createContext("/deleteCompany", new DeleteCompanyHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Company server started at http://localhost:" + port);
    }

    // ===== ROOT =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
<div class="card">
  <div class="card-header">
    <h1 class="card-title">Company Management</h1>
    <p class="card-description">Manage companies: add, view, update or delete.</p>
  </div>
  <div style='margin-top:20px;'>
    <a href="/addCompany" style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">Add Company</a>
    <a href="/viewCompany" style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">View Companies</a>
    <a href="/" style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; display:inline-block;">⬅ Back to Main Menu</a>
  </div>
</div>
""";

            String html = HtmlTemplate.render("Company Management", body);
            sendHtml(exchange, html);
        }
    }

    // ===== ADD COMPANY =====
    static class AddCompanyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, null);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleInsert(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String message) throws IOException {
            String msgHtml = "";
            if (message != null && !message.isEmpty()) {
                msgHtml = "<div style='margin-bottom:15px; padding:10px; background:#e8f5e9; border:1px solid #4CAF50; border-radius:6px; color:#2e7d32;'>"
                        + escapeHtml(message) + "</div>";
            }

            String body = """
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Add Company</h2>
            <p class="card-description">Fill out the form below to add a new company.</p>
          </div>
          <div class="card-body">
            %s
            <form method="post" action="/addCompany" style="max-width:600px;">
              <label>Name:</label><br>
              <input type="text" name="name" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>
              
              <label>Website:</label><br>
              <input type="text" name="website" style="width:100%%; padding:8px; margin-bottom:12px;"><br>
              
              <label>Status:</label><br>
              <input type="text" name="status" style="width:100%%; padding:8px; margin-bottom:12px;"><br>
              
              <label>Status Reason:</label><br>
              <textarea name="status_reason" rows="3" style="width:100%%; padding:8px; margin-bottom:12px;"></textarea><br>
              
              <label>Since Date (YYYY-MM-DD):</label><br>
              <input type="date" name="since_date" style="padding:8px; margin-bottom:12px;"><br>
              
              <label>Founded Year:</label><br>
              <input type="number" name="founded_year" min="1900" max="2100" style="padding:8px; margin-bottom:12px;"><br>
              
              <label>Discontinued Date (YYYY-MM-DD):</label><br>
              <input type="date" name="discontinued_date" style="padding:8px; margin-bottom:12px;"><br>
              
              <label>Branches Count:</label><br>
              <input type="number" name="branches_count" min="0" style="padding:8px; margin-bottom:12px;"><br>
              
              <label>Description:</label><br>
              <textarea name="description" rows="4" style="width:100%%; padding:8px; margin-bottom:12px;"></textarea><br>
              
              <button type="submit" 
                      style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
                      ➕ Add Company
              </button>
            </form>
            <br>
            <div style="margin-top:15px;">
              <a href="/viewCompanies"
                 style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:8px;">
                 📋 View Companies
              </a>
              <a href="/"
                 style="padding:8px 16px; background:#9e9e9e; color:white; text-decoration:none; border-radius:6px;">
                 ⬅ Back
              </a>
            </div>
          </div>
        </div>
        """.formatted(msgHtml);

            String html = HtmlTemplate.render("Add Company", body);
            sendHtml(exchange, html);
        }


        private void handleInsert(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);

            String name = params.getOrDefault("name", "");
            String website = params.getOrDefault("website", "");
            String status = params.getOrDefault("status", "");
            String status_reason = params.getOrDefault("status_reason", "");
            String since_date = params.getOrDefault("since_date", "");
            String founded_year = params.getOrDefault("founded_year", "");
            String discontinued_date = params.getOrDefault("discontinued_date", "");
            String branches_count = params.getOrDefault("branches_count", "");
            String description = params.getOrDefault("description", "");

            String message;
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO company (name, website, status, status_reason, since_date, " +
                        "founded_year, discontinued_date, branches_count, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, website.isEmpty() ? null : website);
                ps.setString(3, status.isEmpty() ? null : status);
                ps.setString(4, status_reason.isEmpty() ? null : status_reason);
                ps.setDate(5, since_date.isEmpty() ? null : Date.valueOf(since_date));
                if (founded_year.isEmpty()) ps.setNull(6, Types.INTEGER);
                else ps.setInt(6, Integer.parseInt(founded_year));
                ps.setDate(7, discontinued_date.isEmpty() ? null : Date.valueOf(discontinued_date));
                if (branches_count.isEmpty()) ps.setNull(8, Types.INTEGER);
                else ps.setInt(8, Integer.parseInt(branches_count));
                ps.setString(9, description.isEmpty() ? null : description);
                ps.executeUpdate();
                message = "✅ Company added successfully!";
            } catch (Exception e) {
                e.printStackTrace();
                message = "❌ Error: " + e.getMessage();
            }

            showForm(exchange, message);
        }
    }



    // ===== VIEW COMPANIES =====
    static class ViewCompanyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Company List</h2>")
                    .append("<p class='card-description'>Below is the list of registered companies</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>Name</th><th>Website</th><th>Status</th><th>Status Reason</th><th>Since Date</th>")
                    .append("<th>Founded Year</th><th>Discontinued Date</th><th>Sector</th><th>Headquarters</th>")
                    .append("<th>Branches</th><th>Description</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT c.company_id, c.name, c.website, c.status, c.status_reason, c.since_date, c.founded_year, " +
                        "c.discontinued_date, c.sector_id, c.headquarters_location_id, c.branches_count, c.description " +
                        "FROM company c ORDER BY c.company_id";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    int id = rs.getInt("company_id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("name"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("website"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("status"))).append("</td>")
                            .append("<td>").append(escapeHtml(truncateText(rs.getString("status_reason"), 30))).append("</td>")
                            .append("<td>").append(rs.getDate("since_date") != null ? rs.getDate("since_date").toString() : "").append("</td>")
                            .append("<td>").append(rs.getInt("founded_year") != 0 ? rs.getInt("founded_year") : "").append("</td>")
                            .append("<td>").append(rs.getDate("discontinued_date") != null ? rs.getDate("discontinued_date").toString() : "").append("</td>")
                            .append("<td>").append(rs.getInt("sector_id") != 0 ? rs.getInt("sector_id") : "").append("</td>")
                            .append("<td>").append(rs.getInt("headquarters_location_id") != 0 ? rs.getInt("headquarters_location_id") : "").append("</td>")
                            .append("<td>").append(rs.getInt("branches_count") != 0 ? rs.getInt("branches_count") : "").append("</td>")
                            .append("<td>").append(escapeHtml(truncateText(rs.getString("description"), 50))).append("</td>")
                            .append("<td>")
                            .append("<a href='/updateCompany?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteCompany?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' class='btn btn-secondary'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Company List", body.toString());
            sendHtml(exchange, html);
        }
    }

    // ===== UPDATE COMPANY =====
    static class UpdateCompanyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                Map<String, String> params = parseQuery(exchange);
                String idStr = params.get("id");
                if (idStr != null) {
                    try (Connection conn = DBUtil.getConnection()) {
                        String sql = "SELECT * FROM company WHERE company_id=?";
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setInt(1, Integer.parseInt(idStr));
                        ResultSet rs = ps.executeQuery();
                        if (rs.next()) {
                            showForm(exchange,
                                    rs.getString("name"),
                                    rs.getString("website"),
                                    rs.getString("status"),
                                    rs.getString("status_reason"),
                                    rs.getDate("since_date") != null ? rs.getDate("since_date").toString() : "",
                                    rs.getInt("founded_year") != 0 ? String.valueOf(rs.getInt("founded_year")) : "",
                                    rs.getDate("discontinued_date") != null ? rs.getDate("discontinued_date").toString() : "",
                                    rs.getInt("sector_id") != 0 ? String.valueOf(rs.getInt("sector_id")) : "",
                                    rs.getInt("headquarters_location_id") != 0 ? String.valueOf(rs.getInt("headquarters_location_id")) : "",
                                    rs.getInt("branches_count") != 0 ? String.valueOf(rs.getInt("branches_count")) : "",
                                    rs.getString("description"),
                                    rs.getInt("company_id"));
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                exchange.sendResponseHeaders(404, -1);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String name, String website, String status,
                              String status_reason, String since_date, String founded_year,
                              String discontinued_date, String sector_id, String location_id,
                              String branches_count, String description, int companyId) throws IOException {

            StringBuilder html = new StringBuilder("""
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; background:#f9f9f9; }
            .card { background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.1); max-width:600px; margin:auto; }
            .card h2 { margin-top:0; }
            .form-group { margin-bottom:15px; }
            label { display:block; font-weight:bold; margin-bottom:5px; }
            input[type=text], input[type=number], input[type=date], textarea, select {
                width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;
            }
            textarea { resize:vertical; }
            .actions { margin-top:20px; }
            .btn { padding:10px 16px; border:none; border-radius:4px; cursor:pointer; text-decoration:none; display:inline-block; }
            .btn-primary { background:#4CAF50; color:white; }
            .btn-secondary { background:#9E9E9E; color:white; margin-left:10px; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Update Company</h2>
            <form method='post' action='/updateCompany'>
    """);

            html.append("<input type='hidden' name='id' value='" + companyId + "'>");

            // fields
            html.append("<div class='form-group'><label>Name</label>")
                    .append("<input type='text' name='name' value='" + escapeHtml(name) + "' required></div>");

            html.append("<div class='form-group'><label>Website</label>")
                    .append("<input type='text' name='website' value='" + escapeHtml(website) + "'></div>");

            html.append("<div class='form-group'><label>Status</label>")
                    .append("<input type='text' name='status' value='" + escapeHtml(status) + "'></div>");

            html.append("<div class='form-group'><label>Status Reason</label>")
                    .append("<textarea name='status_reason' rows='3'>" + escapeHtml(status_reason) + "</textarea></div>");

            html.append("<div class='form-group'><label>Since Date</label>")
                    .append("<input type='date' name='since_date' value='" + since_date + "'></div>");

            html.append("<div class='form-group'><label>Founded Year</label>")
                    .append("<input type='number' name='founded_year' min='1900' max='2100' value='" + founded_year + "'></div>");

            html.append("<div class='form-group'><label>Discontinued Date</label>")
                    .append("<input type='date' name='discontinued_date' value='" + discontinued_date + "'></div>");

            html.append("<div class='form-group'><label>Branches Count</label>")
                    .append("<input type='number' name='branches_count' min='0' value='" + branches_count + "'></div>");

            html.append("<div class='form-group'><label>Description</label>")
                    .append("<textarea name='description' rows='4'>" + escapeHtml(description) + "</textarea></div>");

            // Sector dropdown
            html.append("<div class='form-group'><label>Sector</label><select name='sector_id'>")
                    .append("<option value=''>-- Select Sector --</option>");
            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM sector ORDER BY name");
                while (rs.next()) {
                    int id = rs.getInt("sector_id");
                    String sname = rs.getString("name");
                    html.append("<option value='").append(id).append("'");
                    if (sector_id.equals(String.valueOf(id))) html.append(" selected");
                    html.append(">").append(escapeHtml(sname)).append("</option>");
                }
            } catch (Exception e) { e.printStackTrace(); }
            html.append("</select></div>");

            // Location dropdown
            html.append("<div class='form-group'><label>Headquarters Location</label><select name='location_id'>")
                    .append("<option value=''>-- Select Location --</option>");
            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM location ORDER BY city");
                while (rs.next()) {
                    int id = rs.getInt("location_id");
                    String loc = rs.getString("city") + ", " + rs.getString("country");
                    html.append("<option value='").append(id).append("'");
                    if (location_id.equals(String.valueOf(id))) html.append(" selected");
                    html.append(">").append(escapeHtml(loc)).append("</option>");
                }
            } catch (Exception e) { e.printStackTrace(); }
            html.append("</select></div>");

            // Actions
            html.append("<div class='actions'>")
                    .append("<input type='submit' value='Update Company' class='btn btn-primary'>")
                    .append("<a href='/viewCompanies' class='btn btn-secondary'>Back</a>")
                    .append("</div>");

            html.append("</form></div></body></html>");

            byte[] resp = html.toString().getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            exchange.sendResponseHeaders(200, resp.length);
            try (OutputStream os = exchange.getResponseBody()) { os.write(resp); }
        }

        private void handleUpdate(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String idStr = params.get("id");
            if (idStr == null) return;

            String name = params.getOrDefault("name", "");
            String website = params.getOrDefault("website", "");
            String status = params.getOrDefault("status", "");
            String status_reason = params.getOrDefault("status_reason", "");
            String since_date = params.getOrDefault("since_date", "");
            String founded_year = params.getOrDefault("founded_year", "");
            String discontinued_date = params.getOrDefault("discontinued_date", "");
            String sector_id = params.getOrDefault("sector_id", "");
            String location_id = params.getOrDefault("location_id", "");
            String branches_count = params.getOrDefault("branches_count", "");
            String description = params.getOrDefault("description", "");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE company SET name=?, website=?, status=?, status_reason=?, since_date=?, " +
                        "founded_year=?, discontinued_date=?, sector_id=?, headquarters_location_id=?, " +
                        "branches_count=?, description=? WHERE company_id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, website.isEmpty() ? null : website);
                ps.setString(3, status.isEmpty() ? null : status);
                ps.setString(4, status_reason.isEmpty() ? null : status_reason);
                ps.setDate(5, since_date.isEmpty() ? null : Date.valueOf(since_date));
                if (founded_year.isEmpty()) ps.setNull(6, Types.INTEGER);
                else ps.setInt(6, Integer.parseInt(founded_year));
                ps.setDate(7, discontinued_date.isEmpty() ? null : Date.valueOf(discontinued_date));
                if (sector_id.isEmpty()) ps.setNull(8, Types.INTEGER);
                else ps.setInt(8, Integer.parseInt(sector_id));
                if (location_id.isEmpty()) ps.setNull(9, Types.INTEGER);
                else ps.setInt(9, Integer.parseInt(location_id));
                if (branches_count.isEmpty()) ps.setNull(10, Types.INTEGER);
                else ps.setInt(10, Integer.parseInt(branches_count));
                ps.setString(11, description.isEmpty() ? null : description);
                ps.setInt(12, Integer.parseInt(idStr));
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewCompanies");
            exchange.sendResponseHeaders(302, -1);
        }
    }

    // ===== DELETE COMPANY =====
    static class DeleteCompanyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";
            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM company WHERE company_id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "Company deleted successfully!" : "Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "Error: " + e.getMessage();
                }
            }

            String body = String.format("""
    <div class="card">
      <div class="card-header">
        <h2>Delete Company</h2>
      </div>
      <div class="card-body" style="text-align:center;">
        <p>%s</p>
        <a href="/viewCompanies"
           style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
           ⬅ Back to Company List
        </a>
      </div>
    </div>
    """, escapeHtml(message));


            String html = HtmlTemplate.render("Delete Company", body);
            sendHtml(exchange, html);
        }
    }

    // ===== UTILITIES =====
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    private static Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
        InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
        BufferedReader br = new BufferedReader(isr);
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        String formData = sb.toString();

        Map<String, String> map = new HashMap<>();
        if (formData.isEmpty()) return map;
        String[] pairs = formData.split("&");
        for (String pair : pairs) {
            String[] nv = pair.split("=", 2);
            if (nv.length == 2) {
                map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
        }
        return map;
    }

    private static Map<String, String> parseQuery(HttpExchange exchange) {
        Map<String, String> map = new HashMap<>();
        String query = exchange.getRequestURI().getQuery();
        if (query == null || query.isEmpty()) return map;
        try {
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) {
                    map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
                }
            }
        } catch (UnsupportedEncodingException e) {
            // unlikely, but return what we could parse
            e.printStackTrace();
        }
        return map;
    }

    private static String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#x27;");
    }

    private static String truncateText(String text, int maxLength) {
        if (text == null || text.length() <= maxLength) return text;
        return text.substring(0, maxLength) + "...";
    }
}
