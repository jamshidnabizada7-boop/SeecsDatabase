package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Sector {
    public static void main(String[] args) throws Exception {
        int port = 8001; // use a different port if Founder.java uses 8000
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addSector", new AddSectorHandler());
        server.createContext("/updateSector", new UpdateSectorHandler());
        server.createContext("/deleteSector", new DeleteSectorHandler());
        server.createContext("/viewSectors", new ViewSectorHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("Sector server started at http://localhost:" + port);
    }

    // ===== ROOT =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h1 class="card-title">Sector Management</h1>
                        <p class="card-description">Manage sectors: add, view, update or delete.</p>
                      </div>
                      <div style='margin-top:20px;'>
                        <a href="/addSector" style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">Add Sector</a>
                        <a href="/viewSectors" style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">View Sectors</a>
                        <a href="/" style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; display:inline-block;">⬅ Back to Main Menu</a>
                      </div>
                    </div>
                    """;

            String html = HtmlTemplate.render("Sector Management", body);
            sendHtml(exchange, html);
        }
    }

    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ===== ADD SECTOR =====
    static class AddSectorHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, "");
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }

        private void showForm(HttpExchange exchange, String message) throws IOException {
            String msgHtml = "";
            if (message != null && !message.isEmpty()) {
                msgHtml = "<div style='margin-bottom:15px; padding:10px; background:#e8f5e9; border:1px solid #4CAF50; border-radius:6px; color:#2e7d32;'>"
                        + escapeHtml(message) + "</div>";
            }

            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h2 class="card-title">Add Sector</h2>
                        <p class="card-description">Fill out the form below to add a new sector.</p>
                      </div>
                      <div class="card-body">
                        %s
                        <form method="post" action="/addSector" style="max-width:400px;">
                          <label>Name:</label><br>
                          <input type="text" name="name" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                          <button type="submit" style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">➕ Add Sector</button>
                        </form>
                        <br>
                        <div style="margin-top:15px;">
                          <a href="/viewSectors" style="padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:8px;">📋 View Sectors</a>
                          <a href="/" style="padding:8px 16px; background:#9e9e9e; color:white; text-decoration:none; border-radius:6px;">⬅ Back</a>
                        </div>
                      </div>
                    </div>
                    """.formatted(msgHtml);

            String html = HtmlTemplate.render("Add Sector", body);
            sendHtml(exchange, html);
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String name = params.getOrDefault("name", "");

            String message;
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO sector (name) VALUES (?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.executeUpdate();
                message = "✅ Sector added successfully!";
            } catch (Exception e) {
                e.printStackTrace();
                message = "❌ Error: " + e.getMessage();
            }

            showForm(exchange, message);
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            String formData = body.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== VIEW SECTORS =====
    static class ViewSectorHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Sector List</h2>")
                    .append("<p class='card-description'>Below is the list of registered sectors</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr><th>ID</th><th>Name</th><th>Actions</th></tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM sector ORDER BY sector_id");
                while (rs.next()) {
                    int id = rs.getInt("sector_id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("name"))).append("</td>")
                            .append("<td>")
                            .append("<a href='/updateSector?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteSector?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' class='btn btn-secondary'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Sector List", body.toString());
            sendHtml(exchange, html);
        }
    }


    // ===== UPDATE SECTOR =====
    static class UpdateSectorHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                Map<String, String> params = parseQuery(exchange);
                String idStr = params.get("id");
                if (idStr != null) {
                    try (Connection conn = DBUtil.getConnection()) {
                        String sql = "SELECT * FROM sector WHERE sector_id=?";
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ps.setInt(1, Integer.parseInt(idStr));
                        ResultSet rs = ps.executeQuery();
                        if (rs.next()) {
                            showForm(exchange, rs.getString("name"), rs.getInt("sector_id"));
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                exchange.sendResponseHeaders(404, -1);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, String name, int sectorId) throws IOException {
            String body = """
                        <div class="card">
                          <div class="card-header">
                            <h2 class="card-title">Update Sector</h2>
                            <p class="card-description">Modify the sector name below.</p>
                          </div>
                          <div class="card-body">
                            <form method="post" action="/updateSector" style="max-width:400px; margin:auto;">
                              <input type="hidden" name="id" value="%d">
                              <label>Name:</label><br>
                              <input type="text" name="name" value="%s" required style="width:100%%; padding:8px; margin-bottom:12px;"><br>
                              <button type="submit"
                                      style="padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;">
                                      Update Sector
                              </button>
                              <a href="/viewSectors"
                                 style="padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px; margin-left:10px;">
                                 ⬅ Back
                              </a>
                            </form>
                          </div>
                        </div>
                    """.formatted(sectorId, escapeHtml(name));

            sendHtml(exchange, HtmlTemplate.render("Update Sector", body));
        }

        private void handleUpdate(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String idStr = params.get("id");
            String name = params.get("name");
            if (idStr == null) return;

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE sector SET name=? WHERE sector_id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setInt(2, Integer.parseInt(idStr));
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewSectors");
            exchange.sendResponseHeaders(302, -1);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            String formData = sb.toString();

            Map<String, String> map = new HashMap<>();
            if (formData.isEmpty()) return map;
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== DELETE SECTOR =====
    static class DeleteSectorHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";
            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM sector WHERE sector_id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "✅ Sector deleted successfully!" : "❌ Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "❌ Error: " + e.getMessage();
                }
            }

            String body = """
                        <div class="card">
                          <div class="card-header">
                            <h2>Delete Sector</h2>
                          </div>
                          <div class="card-body" style="text-align:center;">
                            <p>%s</p>
                            <a href="/viewSectors"
                               style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
                               ⬅ Back to Sector List
                            </a>
                          </div>
                        </div>
                    """.formatted(escapeHtml(message));

            sendHtml(exchange, HtmlTemplate.render("Delete Sector", body));
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }
}