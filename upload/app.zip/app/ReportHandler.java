package app;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import utils.DBUtil;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ReportHandler implements HttpHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        StringBuilder html = new StringBuilder();

        html.append("<div class='card'>")
                .append("<div class='card-header'>")
                .append("<h2 class='card-title'>Database Reports</h2>")
                .append("<p class='card-description'>Predefined insights from SEECS Entrepreneurship Database</p>")
                .append("</div>");

        // === List of generic reports ===
        Map<String, String> queries = new LinkedHashMap<>();

// 1. Founders with multiple companies
        queries.put("1. Founders with multiple companies",
                "SELECT f.name AS founder_name, COUNT(cf.company_id) AS company_count " +
                        "FROM founder f " +
                        "JOIN company_founder cf ON f.founder_id = cf.founder_id " +
                        "GROUP BY f.founder_id " +
                        "HAVING COUNT(cf.company_id) > 1");

// 2. Average revenue per year
        queries.put("2. Average revenue per year",
                "SELECT year, AVG(revenue_exact) AS avg_revenue " +
                        "FROM company_annual_data " +
                        "WHERE revenue_exact IS NOT NULL " +
                        "GROUP BY year " +
                        "ORDER BY year");

// 3. Number of entrepreneurs by degree (CS/SE/EE/IT/ICSE)
        queries.put("3. Number of entrepreneurs by degree (CS/SE/EE/IT/ICSE)",
                "SELECT d.department, COUNT(f.founder_id) AS founder_count " +
                        "FROM founder f " +
                        "JOIN degree d ON f.degree_id = d.degree_id " +
                        "WHERE d.department IN ('Computer Science','Software Engineering','Electrical Engineering','Information Technology','Information & Communication Systems Engineering') " +
                        "GROUP BY d.department");

// 4. Entrepreneurs in Pakistan vs abroad
        queries.put("4. Entrepreneurs in Pakistan vs abroad",
                "SELECT CASE WHEN l.country = 'Pakistan' THEN 'Pakistan' ELSE 'Abroad' END AS region, " +
                        "COUNT(DISTINCT cf.founder_id) AS founder_count " +
                        "FROM company c " +
                        "JOIN company_founder cf ON c.company_id = cf.company_id " +
                        "JOIN location l ON c.headquarters_location_id = l.location_id " +
                        "GROUP BY region");

// 5. Average number of employees per company
        queries.put("5. Average number of employees per company",
                "SELECT c.name AS company_name, AVG(cad.employee_count) AS avg_employees " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id");

// 6. Highest-earning founder
        queries.put("6. Highest-earning founder",
                "SELECT f.name, SUM(cad.revenue_exact) AS total_revenue " +
                        "FROM founder f " +
                        "JOIN company_founder cf ON f.founder_id = cf.founder_id " +
                        "JOIN company_annual_data cad ON cf.company_id = cad.company_id " +
                        "GROUP BY f.founder_id " +
                        "ORDER BY total_revenue DESC LIMIT 1");

// 7. Total startups founded this year
        queries.put("7. Total startups founded this year",
                "SELECT COUNT(*) AS startups_this_year " +
                        "FROM company WHERE founded_year = YEAR(CURDATE())");

// 8. Gender distribution of founders
        queries.put("8. Gender distribution of founders",
                "SELECT gender, COUNT(*) AS founder_count " +
                        "FROM founder " +
                        "GROUP BY gender");

// 9. Top 5 companies by employee count
        queries.put("9. Top 5 companies by employee count",
                "SELECT c.name AS company, MAX(cad.employee_count) AS employees " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id " +
                        "ORDER BY employees DESC LIMIT 5");

// 10. Founders per company
        queries.put("10. Founders per company",
                "SELECT c.name AS company, COUNT(cf.founder_id) AS founder_count " +
                        "FROM company c " +
                        "LEFT JOIN company_founder cf ON c.company_id = cf.company_id " +
                        "GROUP BY c.company_id");

// 11. Companies per sector
        queries.put("11. Companies per sector",
                "SELECT s.name AS sector, COUNT(c.company_id) AS company_count " +
                        "FROM sector s " +
                        "LEFT JOIN company c ON s.sector_id = c.sector_id " +
                        "GROUP BY s.sector_id");

// 12. Average age of companies
        queries.put("12. Average age of companies",
                "SELECT AVG(YEAR(CURDATE()) - founded_year) AS avg_age_years " +
                        "FROM company");

// 13. Revenue growth trend by company
        queries.put("13. Revenue growth trend by company",
                "SELECT c.name, MIN(cad.year) AS start_year, MAX(cad.year) AS end_year, " +
                        "(MAX(cad.revenue_exact) - MIN(cad.revenue_exact)) AS growth " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id");

// 14. Founders by gender and degree
        queries.put("14. Founders by gender and degree",
                "SELECT gender, d.department, COUNT(*) AS count " +
                        "FROM founder f " +
                        "JOIN degree d ON f.degree_id = d.degree_id " +
                        "GROUP BY gender, d.department");

// 15. Companies founded per year
        queries.put("15. Companies founded per year",
                "SELECT founded_year, COUNT(*) AS companies " +
                        "FROM company " +
                        "GROUP BY founded_year " +
                        "ORDER BY founded_year");

// 16. Average revenue per employee
        queries.put("16. Average revenue per employee",
                "SELECT c.name, " +
                        "AVG(cad.revenue_exact / NULLIF(cad.employee_count,0)) AS revenue_per_employee " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id");

// 17. Most common founding city
        queries.put("17. Most common founding city",
                "SELECT l.city, COUNT(c.company_id) AS company_count " +
                        "FROM company c " +
                        "JOIN location l ON c.headquarters_location_id = l.location_id " +
                        "GROUP BY l.city " +
                        "ORDER BY company_count DESC LIMIT 1");

// 18. Founders who are solo (1 founder)
        queries.put("18. Founders who are solo (1 founder)",
                "SELECT f.name AS founder_name, COUNT(cf.company_id) AS companies " +
                        "FROM founder f " +
                        "JOIN company_founder cf ON f.founder_id = cf.founder_id " +
                        "GROUP BY f.founder_id " +
                        "HAVING COUNT(cf.company_id) = 1");

// 19. Average companies per founder
        queries.put("19. Average companies per founder",
                "SELECT AVG(company_count) AS avg_companies_per_founder " +
                        "FROM (" +
                        "   SELECT COUNT(cf.company_id) AS company_count " +
                        "   FROM founder f " +
                        "   JOIN company_founder cf ON f.founder_id = cf.founder_id " +
                        "   GROUP BY f.founder_id" +
                        ") AS founder_company_counts");

// 20. Companies with highest single-year revenue
        queries.put("20. Companies with highest single-year revenue",
                "SELECT c.name AS company_name, MAX(cad.revenue_exact) AS peak_revenue " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id " +
                        "ORDER BY peak_revenue DESC LIMIT 5");
// 21. Companies with declining revenue
        queries.put("21. Companies with declining revenue",
                "SELECT c.name, " +
                        "MIN(cad.revenue_exact) AS min_rev, " +
                        "MAX(cad.revenue_exact) AS max_rev " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id " +
                        "HAVING MAX(cad.revenue_exact) < MIN(cad.revenue_exact)");
// 22. Sector with highest average revenue
        queries.put("22. Sector with highest average revenue",
                "SELECT s.name AS sector, AVG(cad.revenue_exact) AS avg_revenue " +
                        "FROM sector s " +
                        "JOIN company c ON s.sector_id = c.sector_id " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY s.sector_id " +
                        "ORDER BY avg_revenue DESC " +
                        "LIMIT 1");

// 23. Sector with most startups founded
        queries.put("23. Sector with most startups founded",
                "SELECT s.name AS sector, COUNT(c.company_id) AS company_count " +
                        "FROM sector s " +
                        "LEFT JOIN company c ON s.sector_id = c.sector_id " +
                        "GROUP BY s.sector_id " +
                        "ORDER BY company_count DESC " +
                        "LIMIT 1");

// 24. Companies with 0 employees (dormant)
        queries.put("24. Companies with 0 employees (dormant)",
                "SELECT c.name " +
                        "FROM company c " +
                        "JOIN company_annual_data cad ON c.company_id = cad.company_id " +
                        "GROUP BY c.company_id " +
                        "HAVING MAX(cad.employee_count)=0");

// 25. Year with most startups founded
        queries.put("25. Year with most startups founded",
                "SELECT founded_year, COUNT(*) AS startup_count " +
                        "FROM company " +
                        "GROUP BY founded_year " +
                        "ORDER BY startup_count DESC " +
                        "LIMIT 1");

        // === Execute each query and render ===
        try (Connection conn = DBUtil.getConnection()) {
            for (Map.Entry<String, String> entry : queries.entrySet()) {
                html.append("<div class='report-section'>")
                        .append("<h3>").append(entry.getKey()).append("</h3>");

                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery(entry.getValue())) {

                    ResultSetMetaData meta = rs.getMetaData();
                    int colCount = meta.getColumnCount();

                    // Table header
                    html.append("<table class='styled-table'><thead><tr>");
                    for (int i = 1; i <= colCount; i++) {
                        html.append("<th>").append(meta.getColumnLabel(i)).append("</th>");
                    }
                    html.append("</tr></thead><tbody>");

                    // Table rows
                    boolean hasRows = false;
                    while (rs.next()) {
                        hasRows = true;
                        html.append("<tr>");
                        for (int i = 1; i <= colCount; i++) {
                            Object val = rs.getObject(i);
                            html.append("<td>").append(val != null ? val.toString() : "-").append("</td>");
                        }
                        html.append("</tr>");
                    }
                    if (!hasRows) {
                        html.append("<tr><td colspan='").append(colCount).append("'>No data</td></tr>");
                    }

                    html.append("</tbody></table>");

                } catch (Exception e) {
                    html.append("<p class='error'>⚠️ Error: ").append(e.getMessage()).append("</p>");
                }

                html.append("</div>");
            }
        } catch (Exception e) {
            html.append("<p class='error'>⚠️ Error connecting DB: ").append(e.getMessage()).append("</p>");
        }

// Add Back button at the end (bottom-left)
        html.append("<div style='margin-top:2rem;text-align:left;'>")
                .append("<button onclick=\"history.back()\" ")
                .append("style='padding:10px 20px;background:#eee;border:1px solid #ccc;border-radius:6px;cursor:pointer;'>")
                .append("⬅ Back</button>")
                .append("</div>");



        // Add CSS
        html.append("<style>")
                .append(".report-section{margin-bottom:2rem;padding:1rem;border:1px solid #ddd;border-radius:8px;}")
                .append(".styled-table{width:100%;border-collapse:collapse;margin-top:0.5rem;}")
                .append(".styled-table th,.styled-table td{padding:8px;border:1px solid #ccc;text-align:left;}")
                .append(".styled-table th{background:#f4f4f4;}")
                .append(".error{color:red;font-weight:bold;}")
                .append("</style>");

        String response = HtmlTemplate.render("Reports Dashboard", html.toString());

        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, response.getBytes().length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(response.getBytes());
        }
    }
}
