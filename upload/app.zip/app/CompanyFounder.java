package app;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import utils.DBUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CompanyFounder {
    public static void main(String[] args) throws Exception {
        int port = 8005; // New port for CompanyFounder
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", new RootHandler());
        server.createContext("/addCompanyFounder", new AddHandler());
        server.createContext("/updateCompanyFounder", new UpdateHandler());
        server.createContext("/deleteCompanyFounder", new DeleteHandler());
        server.createContext("/viewCompanyFounder", new ViewHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("CompanyFounder server started at http://localhost:" + port);
    }

    // ===== ROOT =====
    static class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h1 class="card-title">Company-Founder Links</h1>
                        <p class="card-description">Add or view company-founder relationships.</p>
                      </div>
                      <div style="margin-top:20px;">
                        <a href="/addCompanyFounder" style="padding:10px 20px; background:#2196F3; color:white; text-decoration:none; border-radius:6px; margin-right:10px; display:inline-block;">
                          Add Company-Founder
                        </a>
                        <a href="/viewCompanyFounder" style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block;">
                          View Company-Founders
                        </a>
                      </div>
                      <p style="margin-top:15px;">
                        <a href="/" style="padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;">⬅ Back to Main Menu</a>
                      </p>
                    </div>
                    """;

            String html = HtmlTemplate.render("Company-Founder Links", body);
            sendHtml(exchange, html);
        }
    }

    // Helper method to send HTML response
    private static void sendHtml(HttpExchange exchange, String html) throws IOException {
        byte[] resp = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        exchange.sendResponseHeaders(200, resp.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(resp);
        }
    }

    // ===== HTML ESCAPE HELPER =====
    private static String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ===== ADD COMPANY-FOUNDER =====
    static class AddHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, "", "");
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleAdd(exchange);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, String companyId, String founderId) throws IOException {
            StringBuilder optionsCompany = new StringBuilder();
            StringBuilder optionsFounder = new StringBuilder();

            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT company_id, name FROM company");
                while (rs.next()) {
                    int id = rs.getInt("company_id");
                    String name = rs.getString("name");
                    optionsCompany.append("<option value='").append(id).append("'");
                    if (companyId.equals(String.valueOf(id))) optionsCompany.append(" selected");
                    optionsCompany.append(">").append(name).append("</option>");
                }

                rs = stmt.executeQuery("SELECT founder_id, name FROM founder");
                while (rs.next()) {
                    int id = rs.getInt("founder_id");
                    String name = rs.getString("name");
                    optionsFounder.append("<option value='").append(id).append("'");
                    if (founderId.equals(String.valueOf(id))) optionsFounder.append(" selected");
                    optionsFounder.append(">").append(name).append("</option>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            String body = """
                    <div class="card">
                      <div class="card-header">
                        <h2 class="card-title">Add Company-Founder</h2>
                      </div>
                      <div class="card-body">
                        <form method="post" action="/addCompanyFounder" style="max-width:600px;">
                          <label>Company:</label><br>
                          <select name='company_id'>%s</select><br><br>
                          <label>Founder:</label><br>
                          <select name='founder_id'>%s</select><br><br>
                          <label>Role:</label><br>
                          <input type='text' name='role' style='width:100%%; padding:8px; margin-bottom:12px;'><br>
                          <button type='submit' style='padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;'>➕ Add</button>
                        </form>
                        <div style='margin-top:15px;'>
                          <a href='/viewCompanyFounder' style='padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px;'>📋 View Company-Founders</a>
                          <a href='/' style='padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;'>⬅ Back</a>
                        </div>
                      </div>
                    </div>
                    """.formatted(optionsCompany, optionsFounder);

            String html = HtmlTemplate.render("Add Company-Founder", body);
            sendHtml(exchange, html);
        }

        private void handleAdd(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseFormData(exchange);
            String companyId = params.get("company_id");
            String founderId = params.get("founder_id");
            String role = params.get("role");

            String message;
            try (Connection conn = DBUtil.getConnection()) {
                String sql = "INSERT INTO company_founder (company_id, founder_id, role) VALUES (?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(companyId));
                ps.setInt(2, Integer.parseInt(founderId));
                ps.setString(3, role);
                int rows = ps.executeUpdate();
                message = rows > 0 ? "✅ Added successfully!" : "❌ Add failed!";
            } catch (Exception e) {
                e.printStackTrace();
                message = "❌ Error: " + e.getMessage();
            }

            String body = """
                    <div class="card">
                      <div class="card-body">
                        <h3>%s</h3>
                        <a href='/viewCompanyFounder' style='padding:8px 16px; background:#2196F3; color:white; text-decoration:none; border-radius:6px;'>📋 Back to list</a>
                        <a href='/' style='padding:8px 16px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;'>⬅ Main Menu</a>
                      </div>
                    </div>
                    """.formatted(message);

            String html = HtmlTemplate.render("Add Company-Founder", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseFormData(HttpExchange exchange) throws IOException {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) body.append(line);
            Map<String, String> map = new HashMap<>();
            for (String pair : body.toString().split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }


    // ===== VIEW COMPANY-FOUNDERS =====
    static class ViewHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Company-Founder List</h2>")
                    .append("<p class='card-description'>Below is the list of registered company-founders</p>")
                    .append("</div>")
                    .append("<div style='overflow:auto; max-height:500px; max-width:100%; border:1px solid #ccc;'>")
                    .append("<table style='border-collapse:collapse; width:100%;'>")
                    .append("<thead><tr>")
                    .append("<th>ID</th><th>Company</th><th>Founder</th><th>Role</th><th>Actions</th>")
                    .append("</tr></thead><tbody>");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT cf.id, c.name AS company_name, f.name AS founder_name, cf.role " +
                        "FROM company_founder cf " +
                        "LEFT JOIN company c ON cf.company_id=c.company_id " +
                        "LEFT JOIN founder f ON cf.founder_id=f.founder_id";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    int id = rs.getInt("id");
                    body.append("<tr>")
                            .append("<td>").append(id).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("company_name"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("founder_name"))).append("</td>")
                            .append("<td>").append(escapeHtml(rs.getString("role"))).append("</td>")
                            .append("<td>")
                            .append("<a href='/updateCompanyFounder?id=").append(id)
                            .append("' style='padding:6px 12px; background:#4CAF50; color:white; text-decoration:none; border-radius:4px; margin-right:5px;'>Update</a>")
                            .append("<a href='/deleteCompanyFounder?id=").append(id)
                            .append("' style='padding:6px 12px; background:#f44336; color:white; text-decoration:none; border-radius:4px;' ")
                            .append("onclick='return confirm(\"Are you sure?\")'>Delete</a>")
                            .append("</td>")
                            .append("</tr>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            body.append("</tbody></table></div>")
                    .append("<br><a href='/' class='btn btn-secondary'>⬅ Back</a>")
                    .append("</div>");

            String html = HtmlTemplate.render("Company-Founder List", body.toString());
            sendHtml(exchange, html);
        }
    }


    // ===== UPDATE COMPANY-FOUNDER =====
    static class UpdateHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> queryParams = parseQuery(exchange);
            String idStr = queryParams.get("id");
            if (idStr == null) {
                exchange.sendResponseHeaders(400, -1);
                return;
            }

            int id = Integer.parseInt(idStr);

            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                showForm(exchange, id);
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                handleUpdate(exchange, id);
            } else exchange.sendResponseHeaders(405, -1);
        }

        private void showForm(HttpExchange exchange, int id) throws IOException {
            String companyId = "", founderId = "", role = "";

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "SELECT * FROM company_founder WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    companyId = String.valueOf(rs.getInt("company_id"));
                    founderId = String.valueOf(rs.getInt("founder_id"));
                    role = rs.getString("role");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            StringBuilder body = new StringBuilder();
            body.append("<div class='card'>")
                    .append("<div class='card-header'><h2 class='card-title'>Update Company-Founder</h2>")
                    .append("<p class='card-description'>Modify the company-founder association below.</p></div>")
                    .append("<div class='card-body'>")
                    .append("<form method='post' action='/updateCompanyFounder?id=").append(id).append("'>");

            // Company dropdown
            body.append("<label>Company:</label><br><select name='company_id' style='width:100%; padding:8px; margin-bottom:12px;'>");
            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT company_id, name FROM company ORDER BY name");
                while (rs.next()) {
                    int cid = rs.getInt("company_id");
                    String cname = rs.getString("name");
                    body.append("<option value='").append(cid).append("'");
                    if (companyId.equals(String.valueOf(cid))) body.append(" selected");
                    body.append(">").append(escapeHtml(cname)).append("</option>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            body.append("</select>");

            // Founder dropdown
            body.append("<label>Founder:</label><br><select name='founder_id' style='width:100%; padding:8px; margin-bottom:12px;'>");
            try (Connection conn = DBUtil.getConnection()) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT founder_id, name FROM founder ORDER BY name");
                while (rs.next()) {
                    int fid = rs.getInt("founder_id");
                    String fname = rs.getString("name");
                    body.append("<option value='").append(fid).append("'");
                    if (founderId.equals(String.valueOf(fid))) body.append(" selected");
                    body.append(">").append(escapeHtml(fname)).append("</option>");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            body.append("</select>");

            // Role field
            body.append("<label>Role:</label><br>")
                    .append("<input type='text' name='role' value='").append(escapeHtml(role)).append("' style='width:100%; padding:8px; margin-bottom:12px;'><br>");

            // Buttons
            body.append("<button type='submit' style='padding:10px 20px; background:#4CAF50; color:white; border:none; border-radius:6px; cursor:pointer;'>Update</button> ")
                    .append("<a href='/viewCompanyFounder' style='padding:10px 20px; background:#9E9E9E; color:white; text-decoration:none; border-radius:6px;'>⬅ Back</a>");

            body.append("</form></div></div>");

            String html = HtmlTemplate.render("Update Company-Founder", body.toString());
            sendHtml(exchange, html);
        }

        private void handleUpdate(HttpExchange exchange, int id) throws IOException {
            Map<String, String> params = new AddHandler().parseFormData(exchange);
            String companyId = params.get("company_id");
            String founderId = params.get("founder_id");
            String role = params.get("role");

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE company_founder SET company_id=?, founder_id=?, role=? WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(companyId));
                ps.setInt(2, Integer.parseInt(founderId));
                ps.setString(3, role);
                ps.setInt(4, id);
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }

            exchange.getResponseHeaders().set("Location", "/viewCompanyFounder");
            exchange.sendResponseHeaders(302, -1);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }

    // ===== DELETE =====
    static class DeleteHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQuery(exchange);
            String idStr = params.get("id");
            String message = "";

            if (idStr != null) {
                try (Connection conn = DBUtil.getConnection()) {
                    String sql = "DELETE FROM company_founder WHERE id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(idStr));
                    int rows = ps.executeUpdate();
                    message = rows > 0 ? "✅ Company-Founder deleted successfully!" : "❌ Delete failed!";
                } catch (Exception e) {
                    e.printStackTrace();
                    message = "❌ Error: " + e.getMessage();
                }
            }

            String body = String.format("""
                    <div class="card">
                      <div class="card-header">
                        <h2>Delete Company-Founder</h2>
                      </div>
                      <div class="card-body" style="text-align:center;">
                        <p>%s</p>
                        <a href="/viewCompanyFounder"
                           style="padding:10px 20px; background:#4CAF50; color:white; text-decoration:none; border-radius:6px; display:inline-block; margin-top:15px;">
                           ⬅ Back to Company-Founder List
                        </a>
                      </div>
                    </div>
                    """, escapeHtml(message));

            String html = HtmlTemplate.render("Delete Company-Founder", body);
            sendHtml(exchange, html);
        }

        private Map<String, String> parseQuery(HttpExchange exchange) throws UnsupportedEncodingException {
            Map<String, String> map = new HashMap<>();
            String query = exchange.getRequestURI().getQuery();
            if (query == null) return map;
            for (String pair : query.split("&")) {
                String[] nv = pair.split("=", 2);
                if (nv.length == 2) map.put(URLDecoder.decode(nv[0], "UTF-8"), URLDecoder.decode(nv[1], "UTF-8"));
            }
            return map;
        }
    }
}
